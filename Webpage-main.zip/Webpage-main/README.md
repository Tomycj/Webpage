# Aprendiendo a hablarle a la GPU

Con simulaciones de partículas.